<template>
<div id="app">
  <div id="nav">
    <span v-if="isLoggedIn">Welcome {{ username.toUpperCase() }} | <a @click="logout">Logout</a></span>
  </div>
  <router-view />

</div>
</template>

<script>
export default {
  computed: {
    isLoggedIn: function() {
      if (localStorage.getItem("username")) {
        this.username = localStorage.getItem("username");
      }
      return this.$store.getters.isLoggedIn;
    }
  },
  methods: {
    logout: function() {
      this.$store.dispatch('logout')
        .then(() => {
          this.$router.push('/')
        })
    }
  },
  created: function() {
    this.$http.interceptors.response.use(undefined, function(err) {
      return new Promise(function(resolve, reject) {
        if (err.status === 401 && err.config && !err.config.__isRetryRequest) {
          this.$store.dispatch(logout)
        }
        throw err;
      });
    });
  },
  data: function() {
    return {
      username: ""
    }
  }
}
</script>

<style>
html {
  height: 100%;
}

body {
  min-height: 100%;
  margin: 0;
  padding: 0;
  background: url("../src/assets/dark-honeycomb.png");

}

#app {
  font-family: 'Montserrat', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #333;
  margin-bottom: 50px;
}

#nav {
  padding: 30px;
  text-align: right;
  color: #fff;
}

#nav a {
  font-weight: bold;

}

#nav a:hover {
  text-decoration: underline;
}


ul {
  display: block;
  flex-wrap: wrap;
  list-style-type: none;
  padding: 0;
}

li {
  flex-basis: 300px;
  text-align: left;
  padding: 30px;
}
</style>
