<template>
<div class="movieList">
  <div class="title">
    <h1>List of movies</h1>
  </div>
  <ul>
    <li v-for="movie in movies">
      <movie :name="movie.name" :description="movie.description" :id="movie.id"></movie>
    </li>
  </ul>
</div>
</template>

<script>
import Movie from '@/components/Movie.vue'

export default {
  components: {
    Movie
  },
  data: function() {
    return {
      movies: []
    }
  },
  created: function() {
    var token = localStorage.getItem('token');
    this.$http.get('http://wdassignment.devfl.com/api/movies', {
      headers: {
        'Authorization': 'Bearer ' + token
      }
    }).then(response => {
      for (var i in response.data.data) {
        this.$http.get('http://wdassignment.devfl.com/api/movie?id=' + i, {
          headers: {
            'Authorization': 'Bearer ' + token
          }
        }).then(response => {
          this.movies.push({
            "id": response.data.data.id,
            "name": response.data.data.name,
            "description": response.data.data.description
          });
        }, response => {
          this.movies.push({
            "name": response.message
          })
        });
      };
    }, response => {
      console.log(response);
    });
  }
}
</script>

<style>
.movieList {
  display: block;
  width: 75%;
  margin: 0 auto;
  padding: 30px;
  background-color: #fff;
  -webkit-box-shadow: 0px 0px 30px 5px rgba(255, 255, 255, 0.42);
  -moz-box-shadow: 0px 0px 30px 5px rgba(255, 255, 255, 0.42);
  box-shadow: 0px 0px 30px 5px rgba(255, 255, 255, 0.42);
  border-radius: 20px;
}

.title {
  border-bottom: 2px #00000059 solid;
}
</style>
