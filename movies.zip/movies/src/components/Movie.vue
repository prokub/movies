<template >
<div @click="showDescription = !showDescription" class="movie">
  <div class="movieName">
    <h3>{{ name }}</h3>
  </div>
  <div v-if="showDescription" class="movieDescription">
    <div>{{description}}
    </div>
  </div>
  <hr />
</div>
</template>

<script>
export default {
  props: [
    "name",
    "description",
    "id"
  ],
  data: function() {
    return {
      showDescription: false
    }
  }
}
</script>

<style lang="css" scoped>

.movieName:hover{
  text-decoration: underline;
}
</style>
