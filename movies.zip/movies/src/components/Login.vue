<template>
<div>
  <form @submit.prevent="login">
    <div class="form-group">
      <h1>Sign in</h1>
      <div v-if="isLogin=='error'">
        <div class="alert alert-danger" role="alert">
          Wrong username and/or password
        </div>
      </div>
      <input required v-model="username" type="text" class="form-control" id="exampleInputName" placeholder="Enter username" />
    </div>
    <div class="form-group">
      <input required v-model="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" />
    </div>
    <button type="submit" class="btn btn-primary btn-lg">Login</button>
  </form>
</div>
</template>
<script>
export default {
  data() {
    return {
      username: "",
      password: "",
    }
  },
  computed: {
    isLogin: function() {
      return this.$store.getters.authStatus;
    }
  },
  methods: {
    login: function() {
      let username = this.username
      let password = this.password
      this.$store.dispatch('login', {
          username,
          password
        })
        .then(() => this.$router.push('/secure'))
        .catch(err => console.log(err))
      this.$emit("getUsername", username);
    }
  }
}
</script>

<style>
form h1 {
  color: #FFF;
}

form {
  display: block;
  height: 200px;
  width: 20%;
  margin: auto;
  text-align: center;
  border-radius: 4px;
}
</style>
